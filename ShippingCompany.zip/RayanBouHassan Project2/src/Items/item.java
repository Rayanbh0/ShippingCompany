// Rayan Bou Hassan 
//-----------------
// Matriculation Number: 14776037
//----------------------
package Items;
import java.util.Scanner; 
import Test.test;
	
	public abstract class item {
			
				
			
			private String product; 
			private double weight;
			private double Totalweight; 
			private int quantity;
			private double volume;
			private double Totalvolume; 
			
			
			
		public item(){
				Scanner itemScan = new Scanner(System.in);
				
				// input the product

System.out.println(" ");
System.out.println("*******************************************************************");
System.out.println("---Products List---");
System.out.println("-------");
System.out.println(" Laptop ");
System.out.println(" Mouse ");
System.out.println(" Desktop ");
System.out.println(" Lcd ");
System.out.println("-------");
System.out.println("*******************************************************************");
				
				System.out.println("Please choose a product from the above list");
				this.product = itemScan.next();
				
				// input item quantity
				System.out.println("Please enter the product's quatity: ");
				this.quantity = itemScan.nextInt();
				
				System.out.println("Please enter the product's weight in Kg");
				this.weight = itemScan.nextDouble();
				
				this.Totalweight = this.weight * this.quantity;
				
				//itemScan.close();
			}
		

		//setters 

			public void quantity_setter(int quantity) {
				this.quantity = quantity;
			}
			public void volume_setter(double volume) {
				this.volume = volume;
			}
			// getters
			
			public String product_getter() {
				return this.product;
			}
			
			public double weight_getter() {
				return this.weight;
			}
			
			public double Totalweight_getter() {
				return this.Totalweight;
			}
			
			public int quantity_getter() {
				return this.quantity;
			}
			
			public double volume_getter() {
				return this.volume;
			}
			
			public double Totalvolume_getter() {
				return this.Totalvolume;
			}
			
			//methods
			
			public abstract void volume();
			
			public abstract void printItemInfo();
			
			public void total_volume() {
				this.Totalvolume = this.volume*this.quantity;
			
			}
	

	}
	


