package Items;
import java.util.Scanner;

public class Pentagonpackage extends item{

	private double side;
	private double height;
	private double apothem;
	public Pentagonpackage(){
		Scanner pentagonScan = new Scanner(System.in);
		
		// input pentgon's dimensions
		System.out.println("Please Insert the size of the package \n length value: ");
		this.side = pentagonScan.nextDouble();
		
		System.out.println("\n height value: ");
		this.height = pentagonScan.nextDouble();
		
		System.out.println("\n apothem value: ");
		this.apothem = pentagonScan.nextDouble();
		
		this.volume();
		
		
	}
	
	public void volume() {
		
		super.volume_setter(5/2 *this.side *this.height*this.apothem);
		super.total_volume();
	}

	@Override
	public void printItemInfo() {
		// TODO Auto-generated method stub
		
	}
	
}

