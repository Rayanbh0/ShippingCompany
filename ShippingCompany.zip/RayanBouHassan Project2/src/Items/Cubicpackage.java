package Items;
import java.util.Scanner;

public class Cubicpackage extends item{

	private double side;
	
	public Cubicpackage(){
		Scanner cubeScan = new Scanner(System.in);
		
		// input cube's side value
		System.out.println("Please Insert the size of the package \nside value: ");
		this.side = cubeScan.nextDouble();
		
		this.volume();
		
		//cubeScan.close();
	}
	
	public void volume() {
		
		super.volume_setter(this.side*3);
		super.total_volume();
	}
	
	public void printItemInfo() {
		// TODO Auto-generated method stub
	}
}

