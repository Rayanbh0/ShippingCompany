package Items;
import java.util.Scanner;

public class Cylinderpackage extends item{
	
	private double radius;
	private double height;
	
	public Cylinderpackage(){
		Scanner cylinderScan = new Scanner(System.in);
		
		// input cylinder's dimentions
		System.out.println("Please Insert the size of the box in meters \nradius value: ");
		this.radius = cylinderScan.nextDouble();
		System.out.println("\nheight value: ");
		this.height = cylinderScan.nextDouble();
		
		this.volume();
		
		
	}

	@Override
	public void volume() {
		// TODO Auto-generated method stub
		super.volume_setter(Math.PI*Math.pow(this.radius, 2)*this.height);
		super.total_volume();
		
	}

	// unimplemented method (empty)
	@Override
	public void printItemInfo() {
		// TODO Auto-generated method stub
		
	}

	

}

