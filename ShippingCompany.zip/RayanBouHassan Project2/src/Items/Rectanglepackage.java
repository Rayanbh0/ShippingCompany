package Items;
import java.util.Scanner;

public class Rectanglepackage extends item{
	
	private double length;
	private double width;
	private double height;
	
	public Rectanglepackage(){
		Scanner rectanguleScan = new Scanner(System.in);
		
		// input rectangule's dimension value
		System.out.println("Please Insert the size of the box in meters \nlenght value: ");
		this.length = rectanguleScan.nextDouble();
		
		System.out.println("\nwidth value: ");
		this.width = rectanguleScan.nextDouble();
		
		System.out.println("\nheight value: ");
		this.height = rectanguleScan.nextDouble();
		
		this.volume();
		
		
	}
	
	public void volume() {
		
		super.volume_setter(this.length*this.height*this.width);
		super.total_volume();
	}
	
	public void printItemInfo() {
		// TODO Auto-generated method stub
	}

}
