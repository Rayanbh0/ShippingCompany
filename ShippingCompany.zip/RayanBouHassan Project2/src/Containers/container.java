// Rayan Bou Hassan 
//-----------------
// Matriculation Number: 14776037
//-------------------------------

package Containers;

public abstract class container {
	
	private double height;
	private double width;
	private double length;
	private double volume;
	private int qty;
	
	public container() {
		this.qty = 0;
	}
		
		// getters and setters are created for the item or shape size calculations.
		
		public double height_getter() {
			return this.height;
		}
		
		public double width_getter() {
			return this.width;
		}
		
		public double length_getter() {
			return this.length;
		}
		
		public double volume_getter() {
			return this.volume;
		}
		
		public int quantities_getter() {
			return this.qty;
		}
		
			public void height_setter(double height) {
				this.height = height;
			}
			
			public void width_setter(double wide) {
				this.width = wide;
			}
			
			public void length_setter(double length) {
				this.length = length;
			}
			
			public void quantities_setter(int quantity) {
				this.qty += quantity;
			}
		
		// methods
		
		public abstract void printContainerInfo();
		
		public void volume() {
			this.volume = this.height*this.length*this.width;
		}



}