package Containers;

public class Bigcontainer extends container{

	private int cost;
	
	public Bigcontainer() {
		
		super.height_setter(2.59);
		super.length_setter(12.01);
		super.width_setter(2.43);
		this.cost = 1800;
		
		super.volume();
	}
	
	// getters
	
	public int cost_getter() {
		return this.cost;
	}
	
	
	//methods
	
	public void printContainerInfo() {
		
		String containerInfo = "";
		
		for(int i=0;i<100;i++) {
			containerInfo += "*";
		}
		
		containerInfo += "\n\t\t CONTAINER INFO\n";
		for(int i=0;i<100;i++) {
			containerInfo += "*";
		}
		containerInfo += "\n\n";
		
		containerInfo += "Container Type: Big Container\n";
		containerInfo += "Container Cost: " + Integer.toString(this.cost)+"\n";
		containerInfo += "Container height: " + Double.toString(super.height_getter())  +"\n";
		containerInfo += "Container lenght: " + Double.toString(super.length_getter())  +"\n";
		containerInfo += "Container wide: " + Double.toString(super.width_getter())  +"\n";
		containerInfo += "container Volume: "+ Double.toString(super.volume_getter()) + "\n";
		
		containerInfo += "\n";
		
		for(int i=0;i<100;i++) {
			containerInfo += "*";
		}
		
		System.out.println(containerInfo);
		
	}
}

