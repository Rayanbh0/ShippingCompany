// Rayan Bou Hassan 
//-----------------
// Matriculation Number: 14776037
//----------------------

package Methods;

import java.util.ArrayList;
import java.util.Scanner;

import Containers.Bigcontainer;
import Containers.Smallcontainer;
import Items.*;


public class calculation {
	// An array is created to store the order information.
	
	private ArrayList<item> order = new ArrayList<item>(); 
	
	public calculation() {
	}


	
	//Here i created all the methods needed to calculate the total (weight,volume), shipping price,arraylist,shopping cart.
	// And at the end is the important part w used in project1 the best shipping method.
	

	public void add_item(item item) {
		this.order.add(item);
	}
	

	public void add_order() {
		
		Scanner orderScan = new Scanner(System.in);
		char Packageshape;
		char add_other;
		
		do {
			System.out.println("-------------------------------------------");
			System.out.println("Please choose the packaging of your product \n (A) Cubic package \n (B) Rentangular package "+
						"\n (C) Cylinderical box \n (D) Pentagon package");
			System.out.println("-------------------------------------------");
			
			Packageshape=orderScan.next().toUpperCase().charAt(0);
		
			switch (Packageshape) {
		
				case 'A':
					add_item(new Cubicpackage());
					break;
				case 'B':
					add_item(new Rectanglepackage());
					break;
				case 'C':
					add_item(new Cylinderpackage());
					break;
				case 'D':
					add_item(new Pentagonpackage());
					break;

				default:
					System.out.println("Please one of the above choices only");
					break;
			}
		
			System.out.println("Do you want to add to your order? (y) Yes (n) No");
			add_other = orderScan.next().toLowerCase().charAt(0);
		}while(add_other=='y');
		
		
	}
	

	public void printOrderInformation() {
		
	
		
		
		System.out.print("\n\t\t SHOPPING CART \n");
		
		System.out.println();
		for(int i = 0; i<this.order.size(); i++ ) {
			
			System.out.println("| "+ (i+1) +"\t| "+ this.order.get(i).quantity_getter() +"\t\t| "+ this.order.get(i).product_getter()+"\t\t|"+ String.format("%.2f",this.order.get(i).Totalvolume_getter())+"m3");
			
			}
		
		}
	
	

	public double Totalvolume(ArrayList<item> order) {
		
		double Totalvolume=0;
		
		for (item i : order) {
			Totalvolume += i.Totalvolume_getter();
		}
		
		return Totalvolume;
	}
	

	public double Totalweight(ArrayList<item> order) {
		
		double total_weight=0;
		
		for (item i : order) {
			total_weight += i.Totalweight_getter();
		}
		
		return total_weight;
	}
	
	
	public long shipping_price(Bigcontainer bigcontainer, Smallcontainer smallcontainer) {
		
		long shipping_price =0L;
		
		shipping_price = bigcontainer.quantities_getter()*bigcontainer.cost_getter() + smallcontainer.quantities_getter()*smallcontainer.cost_getter();
		
		return shipping_price;
	}
//---------------------------------------------------------------------------
	public void best_shipping() {
		
		Bigcontainer bigcontainer = new Bigcontainer();
		Smallcontainer smallcontainer = new Smallcontainer();
		
		double total_volume = this.Totalvolume(this.order);
		double Totalweight = this.Totalweight(this.order);
		
		if(total_volume<=smallcontainer.volume_getter()) {
			smallcontainer.quantities_setter(1);
			smallcontainer.cost_setter(Totalweight);
			
		}else if (total_volume>=smallcontainer.volume_getter() && total_volume<=bigcontainer.volume_getter()) {
			bigcontainer.quantities_setter(1);
		}else {
			bigcontainer.quantities_setter((int) (total_volume/bigcontainer.volume_getter()));
			
			if((total_volume%bigcontainer.volume_getter())<=smallcontainer.volume_getter()) {
				smallcontainer.quantities_setter(1);
				smallcontainer.cost_setter(((total_volume%bigcontainer.volume_getter())/total_volume) * Totalweight);
			}else {
				bigcontainer.quantities_setter(1);
			}
		}
		
	
		
		System.out.print("\n\t This is our latest offer\n");
		
			System.out.print("\t---------------------------");
		
		System.out.println("\n Number Of Big Containers: " + bigcontainer.quantities_getter());
		System.out.println("Number Of Small Containers: " + smallcontainer.quantities_getter());
		System.out.println("Number Of Products For Shippment: " + this.order.size());
		System.out.println("Total estimated Price includes shippment: " + this.shipping_price(bigcontainer, smallcontainer) + "�");
		
	}

}
