// Rayan Bou Hassan 
//-----------------
// Matriculation Number: 14776037
//----------------------

package Test;
import java.util.Scanner;

import Containers.Bigcontainer;
import Containers.Smallcontainer;
import Methods.calculation;

public class test {

	public static void main(String[] args) {
		

		test  test = new test();
		
		test.menu();
		
		
	}
	
	
public void menu() {
		
		Scanner menuScan = new Scanner(System.in);
		char option;
		System.out.println("\n");
		Design();
		Design2();
		System.out.println("\t\n    Welcome to our electronic store\t\n");
		Design2();
		Design();
		System.out.println("\n\n Here you can find the best shipping method and products.");
		System.out.println("\n please choose one of the below services to start shopping : \n");
		System.out.println("(1) Start surffing the store");
		System.out.println("(2) Check out our Suppliers");
		System.out.println("(3) About Us Page");
		System.out.println("(4) Check out our Product's specs card.");
		option = menuScan.next().toUpperCase().charAt(0);
		System.out.println("|");
		System.out.println("|");
		
		
		switch (option) {
			case '1':
				
				calculation order = new calculation();
					
				order.add_order();
				
				subMenu(order);
				
				break;
			
            case '2':
				Design();
	               System.out.println(" \n\tArrow Electronics, Inc.\t\n");
	               System.out.println("\n\tFuture Electronics.\t\n");
	               System.out.println("\n\tSmith.\t\n");
                Design();
           
	               menu();
	               menuScan.next();
				break;
            case '3':
				System.out.println("---------------------------------------------------------------------------------------");
	               
				System.out.println("\t\t\tAbout Us\t\t\t");
				
				System.out.println("\nWelcome to Rayan Electronics, your number one source for all High tech products. ");
	               System.out.println("\nWe're dedicated to providing you the best of electronic gadgets that helps you improve your life and working experience, "
	            	    + "\r\n"
	            		+ "with a focus on dependability. customer service, and liability in ordering.\r\n"
	               		+ "\r\n"
	               		+ "We're working to turn our passion for electronics into a booming online store."
	               		+ "\r\n"
	               		+ " We hope you enjoy our products as much as we enjoy offering them to you.\r\n"
	               		+ "\r\n"
	               		+ "Sincerely,\r\n"
	               		+ "\r\n"
	               		+ "Rayan Bou Hassan");
	             
	             System.out.println("---------------------------------------------------------------------------------------");
           
menu();
 menuScan.next();
break;
 case '4':
	do {
		System.out.println("\nTake a look with more details on our high tech : \n");
		System.out.println("(1) Laptop");
		System.out.println("(2) Mouse");
		System.out.println("(3) Desktop");
		System.out.println("(4) Lcd");
					
					
option = menuScan.next().toUpperCase().charAt(0);
				
switch (option) {
			case '1':
			System.out.println("--- core i7 --- 16gb ram --- 16 inch display");
			break;
			case '2':
			System.out.println("--- rgb light --- 4 side buttons --- high sensetivity sensor");
			break;
		    case '3':
			System.out.println("--- core i9 --- 32gb ram DDR4 --- Water cooled system");
			break;
			case '4':
			System.out.println("--- sRGB display --- Mate screen finishing --- 31 inch display");
			break;
						
						
						
						default:
							System.out.println("Please select a valid option.");
							break;
					}
					System.out.println("Do you want to return to the previous menu? Y/N");
					option = menuScan.next().toUpperCase().charAt(0);
				}while(option=='N');
				menu();
				break;
			
			default:
				do {
					System.out.println("Please select a valid option.");
					menu();
				}while(option == 'N');
				break;
		}
		
		
	}

// Design used for enhancing the code and easy to use .
//--------------------------------------------------------------------------------------
public void Design() {
	for(int i=0; i<40;i++) {
		System.out.print("_");
	}
}

public void Design2() {
	for(int i=0; i<10;i++) {
		System.out.print("|");
	}
}
//-------------------------------------------------------------------------------------------
public void subMenu(calculation order) {
	
	Scanner submenuScan = new Scanner(System.in);
	
	System.out.println("\n Please to complete the proccess select one of the below services : \n");
	System.out.println("(A) Check the Shopping cart");
	System.out.println("(B) Shipping Info");
	System.out.println("(C) Buy Now");
	
	char option = submenuScan.next().toUpperCase().charAt(0);

	switch (option) {
		case 'A':
			order.printOrderInformation();
			subMenu(order);
			break;
		case 'B':
			System.out.println("Your shipping Adress is:");
			System.out.println("\n\t Home: Berlin\t\n");
			System.out.println("\n\t Postal Code: 10115\t\n");
			System.out.println("Shipping estimated time: 4 business days");
			System.out.println("Payment : Cash on Delivery");
			subMenu(order);
			break;
		
		case 'C':
			order.best_shipping();
				System.out.println("\nThanks for purchasing from us.");
				System.out.println("\nYour order is on its way :)");
				
				System.exit(0);
			
			subMenu(order);
		default:
			menu();
			break;
	}
	

}


}